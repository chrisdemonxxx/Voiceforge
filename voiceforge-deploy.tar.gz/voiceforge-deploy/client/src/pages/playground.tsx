import { Link } from "wouter";
import RealTimeLab from "./realtime-lab";

export default function Playground() {
  return <RealTimeLab />;
}
